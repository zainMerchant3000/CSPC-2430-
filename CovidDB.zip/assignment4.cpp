// assignment4.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <vector>
#include <iostream>
#include "SeperateChaining.h"
#include "DataEntry.h"
#include <string>
#include <fstream>
#include "CovidDB.h"
using namespace std;
//method prototype
void covidTracker(CovidDB&);
void menu();
void readInFile(CovidDB&);
std::vector<std::string> split(std::string const& s, char delim) {
    //function to split words based on delimeters (commas -> ,)
    std::vector<std::string> res;//creating vector of characters
    size_t i = 0;
    for (size_t k = 0; k < s.size(); k++) {//go through each character
        if (s[k] == delim) {//if character has delimeter
            res.push_back(s.substr(i, k - i));//
            i = k + 1;
        }
    }
    if (i < s.size()) {
        res.push_back(s.substr(i, s.size()));
    }
    return res;//return vector of characters not seperated by delimeters
}//split

int main()
{

    int tableSize = 17;//create variable that stores size of hash table (which is 17)
    CovidDB recordList(tableSize);
    // CovidDB recordList(17);//create vector of dataEntrys
    //object recordList has 2D vector (inner vector is DataEntrys)
    covidTracker(recordList);//user interface function



}//main

void covidTracker(CovidDB& recordList) {

    bool done = false;
    int choice;
    while (!done) {
        menu();//1) call menu
        cout << endl << "enter your choice here: " << endl;//2) prompt user
        cin >> choice;//3) store user's choice
        if (choice == 0) {//if user enters 0
            done = true;
        }//if
        else if (choice == 1) {
                recordList.clearVector();//destory 2D vector
                recordList.reSize(17);
                //cout << "size: " << recordList.v.size() << endl;
                readInFile(recordList);//create another initial hash Table
                //cout << "size: " << recordList.v.size() << endl;
        }// else if
        else if (choice == 2) {
            //adding new DataEntry
            string countryDate;
            string countryName;
            int numberOfDeaths;
            int covidCases;

            cout << endl << "type in the name of your country in your entry: ";
            cin >> countryName;

            cout << endl << "type in the date of your entry: ";
            cin >> countryDate;

            cout << endl << "type in the number of Covid cases: ";
            cin >> covidCases;

            cout << endl << "type in the number of Covid deaths: ";
            cin >> numberOfDeaths;

            DataEntry entry(countryDate, countryName, covidCases, numberOfDeaths);

            recordList.add(entry, true);//true -> has read entire file (initial hash table
            //has been completed at this point (all subsequent entrys are from user not file)
            //
        }//else if (choice == 2)

        else if (choice == 3) {
           // cout << "size: " << recordList.v.size() << endl;
            //get a DataEntry
            string country;//variable to store user's response
            cout << endl << "enter in the country which you want to look at: " << endl;
            cin >> country;
            auto* a = recordList.get(country);
            if (a == nullptr) {//if country is not found (returns nullptr)
                cout << endl << "Null" << endl;
            }//if
            else {//otherwise (country exists)
                cout << "number of cases: " << a->getCases() << endl;
                cout << "number of deaths: " << a->getDeaths() << endl;
                cout << "date: " << a->getDate() << endl;
            }//else

        }//else if (choice == 3)
        else if (choice == 4) {
            //remove a country
            string countryToRemove;
            cout << endl << "Enter in the country you want to remove: ";
            cin >> countryToRemove;
            recordList.remove(countryToRemove);
        }//else if (choice == 4)
        else if (choice == 5) {
            //display Hash Table
            cout << endl << "displaying current Hash table: " << endl;
            recordList.display();
        }//else if (choice == 5)
    }//while (!done)
}//covidTracker

void menu() {
    cout << endl << "Covid Tracker: " << endl;
    cout << "Please choose the operation you want: " << endl;
    cout << "1. Create the initial hash table" << endl;
    cout << "2. Add a new data entry:" << endl;
    cout << "3. Get a data entry" << endl;
    cout << "4. Remove a data entry" << endl;
    cout << "5. Display hash table" << endl;
    cout << "0. Quit the system" << endl;
}//menu

void readInFile(CovidDB& recordList) {//function that reads in file
    //int tableSize = 17;
    //CovidDB recordList(tableSize);//create new Object
     // open the file
    ifstream file("C:\\Users\\zain7\\Downloads\\WHO-COVID-Data.csv");

    if (file.is_open()) {//checking if file is open

        cout << "Open File Success" << endl;

        string line;//create string variable line 

        while (getline(file, line)) {//while entry exists (extract each line/entry in CovidData csv file

            // split the content in each line
            vector<string> result = split(line, ',');
            //result -> has the four DataEntry attributes (or each DataEntry field entry as four different
            // strings

            // wrap up all the data in the vector of strings to a cvsdata type and push it to the vector
            DataEntry oneEntry(result[0], result[1], std::stoi(result[2]), std::stoi(result[3]));//passing array of strings
            //in each vector entry into appropiate data type (c_deaths and c_cases must be converted from string to int)
            recordList.add(oneEntry, false);//push completed dataEntry object (single data entry into recordList)
            //false -> has not read entire file
        }//while
    }//if file is open
}//readInFile



